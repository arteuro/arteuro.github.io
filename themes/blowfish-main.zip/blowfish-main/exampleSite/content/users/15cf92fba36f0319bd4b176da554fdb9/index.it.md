---
                title: "Adam Madej - Gameplay Animator"
                tags: [Sito di portafoglio, Blog, Sito personale]
                externalUrl: "http://www.adammadej.com/"
                weight: 661
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

