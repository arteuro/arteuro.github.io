---
                title: "asterisk.lol"
                tags: [ブログ, パーソナルサイト]
                externalUrl: "https://asterisk.lol"
                weight: 591
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

