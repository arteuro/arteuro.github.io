---
                title: "georgiancodeclub.github.io"
                tags: [College club site]
                externalUrl: "https://georgiancodeclub.github.io"
                weight: 71
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
