---
                title: "insidemordecai.com"
                tags: [Personal site]
                externalUrl: "https://insidemordecai.com"
                weight: 101
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
