---
                title: "technicaldc.github.io"
                tags: [Sito personale, Blog]
                externalUrl: "https://technicaldc.github.io/"
                weight: 551
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

