---
                title: "micheledinelli.github.io"
                tags: [个人网站, 投资组合网站, 学术界]
                externalUrl: "https://micheledinelli.github.io"
                weight: 781
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

