---
                title: "Handbook on Teaching Empirical Software Engineering: Online Materials"
                tags: [本, アカデミア]
                externalUrl: "https://www.emse.education"
                weight: 871
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

