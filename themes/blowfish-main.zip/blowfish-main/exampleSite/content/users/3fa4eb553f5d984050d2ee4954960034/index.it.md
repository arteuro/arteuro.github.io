---
                title: "Lazy Product Reviews"
                tags: [Sito personale, Blog]
                externalUrl: "https://lazyproductreviews.com/"
                weight: 971
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

