---
                title: "fahru.my.id"
                tags: [パーソナルサイト]
                externalUrl: "https://www.fahru.my.id"
                weight: 81
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

