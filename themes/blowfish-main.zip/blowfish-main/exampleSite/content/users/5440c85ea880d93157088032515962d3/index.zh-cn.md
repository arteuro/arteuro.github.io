---
                title: "fahru.my.id"
                tags: [个人网站]
                externalUrl: "https://www.fahru.my.id"
                weight: 81
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

