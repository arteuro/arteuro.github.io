---
                title: "innerknowing"
                tags: [Sito personale, Modellatore]
                externalUrl: "https://innerknowing.xyz/en/"
                weight: 641
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

