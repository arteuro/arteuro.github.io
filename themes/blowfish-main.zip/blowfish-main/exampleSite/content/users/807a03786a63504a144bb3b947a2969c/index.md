---
                title: "Joshua Blais"
                tags: [Personal Site,Author,Digital Garden]
                externalUrl: "https://joshblais.com/"
                weight: 721
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
