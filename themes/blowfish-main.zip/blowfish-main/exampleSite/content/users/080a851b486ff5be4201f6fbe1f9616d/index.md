---
                title: "merox.dev"
                tags: [Personal site,Blog,Documentation,CV]
                externalUrl: "https://merox.dev"
                weight: 901
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
